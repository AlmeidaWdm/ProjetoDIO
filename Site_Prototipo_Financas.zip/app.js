
// Estado simples em memória
const state = {
  receitas: 5000.00,
  despesas: 1750.00,
  lista: []
};

// Helpers
const brl = v => v.toLocaleString('pt-BR', { style:'currency', currency:'BRL' });
const parseValor = str => {
  // aceita "R$ x" ou números; remove tudo que não for dígito/comma/dot
  const clean = (str || '').toString().replace(/[^\d.,-]/g, '').replace(',', '.');
  const n = parseFloat(clean);
  return isNaN(n) ? 0 : n;
};

function updateUI(){
  const saldo = state.receitas - state.despesas;
  document.getElementById('receitas').textContent = brl(state.receitas);
  document.getElementById('despesas').textContent = brl(state.despesas);
  const saldoEl = document.getElementById('saldo');
  saldoEl.textContent = brl(saldo);
  saldoEl.className = 'value ' + (saldo >= 0 ? 'green' : 'red');

  const comprometimento = Math.min(100, Math.round((state.despesas / state.receitas) * 100));
  document.getElementById('comprometimento').style.width = comprometimento + '%';
  document.getElementById('comprometimentoLabel').textContent = `${comprometimento}% dos vencimentos comprometidos`;
  document.getElementById('alert80').style.display = comprometimento >= 80 ? 'block' : 'none';
  document.getElementById('alertSaldo').style.display = saldo > 0 ? 'block' : 'none';
}

function showScreen(name){
  document.getElementById('screen-dashboard').style.display = name==='dashboard' ? 'block' : 'none';
  document.getElementById('screen-expense').style.display = name==='expense' ? 'block' : 'none';
  document.querySelectorAll('aside .item').forEach(el => {
    el.classList.toggle('active', el.dataset.screen === name);
  });
}

function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 1800);
}

// Navegação
window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('toDashboard').onclick = () => showScreen('dashboard');
  document.getElementById('toExpense').onclick = () => showScreen('expense');
  document.querySelectorAll('aside .item').forEach(el => {
    if(el.dataset.screen){ el.onclick = () => showScreen(el.dataset.screen); }
  });
  document.getElementById('goAddExpense').onclick = () => showScreen('expense');

  // Adicionar renda simples
  document.getElementById('addIncome').onclick = () => {
    const val = prompt('Valor da renda (ex.: 500):');
    const n = parseValor(val);
    if(n > 0){ state.receitas += n; updateUI(); toast('Renda adicionada'); }
  };

  // Form de despesas
  const form = document.getElementById('expenseForm');
  document.getElementById('cancelExpense').onclick = () => { form.reset(); showScreen('dashboard'); };
  form.onsubmit = (e) => {
    e.preventDefault();
    const item = {
      descricao: document.getElementById('descricao').value.trim(),
      valor: parseValor(document.getElementById('valor').value),
      categoria: document.getElementById('categoria').value,
      forma: document.getElementById('forma').value,
      data: document.getElementById('data').value,
      parcelas: parseInt(document.getElementById('parcelas').value||'1',10)
    };
    if(!item.descricao || item.valor <= 0){ toast('Preencha descrição e valor válido'); return; }
    state.lista.push(item);
    state.despesas += item.valor; // simples: soma valor total
    form.reset();
    showScreen('dashboard');
    updateUI();
    toast('Despesa salva com sucesso');
  };

  // Inicial
  updateUI();
});
