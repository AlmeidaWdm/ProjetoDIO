
# Protótipo de Finanças (HTML)

Este pacote contém uma versão de site (HTML/CSS/JS) do protótipo de controle de finanças pessoais.

## Como usar
1. Extraia o arquivo ZIP.
2. Abra `index.html` no navegador (Chrome, Edge ou Firefox).
3. Use os botões para navegar entre **Dashboard** e **Cadastrar Despesa**.
4. Clique em **Adicionar renda** para simular aumento de receitas.
5. Cadastre uma despesa para ver os totais e os alertas atualizarem.

## Arquivos
- `index.html` — estrutura das telas.
- `styles.css` — estilos (layout, cores, responsividade).
- `app.js` — interatividade (estado, navegação, cálculos).

## Próximos passos (sugestões)
- Persistência com LocalStorage.
- Gráficos via Chart.js.
- Publicação em GitHub Pages.
- Transformar em PWA (instalável no smartphone).
